package oop.ex1B4;

abstract public class Figure {

  abstract public double getArea();

  abstract public double getPerimeter();
}
