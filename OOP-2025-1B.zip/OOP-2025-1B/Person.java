public class Person {
  // (1)
  String name = "name";

  // (2)
  String getName() {
    return name;
  }

  // (3)
  void setName(String name) {
    this.name = name;
  }
}